 <?php /* AD: 970x90 */ ?>
     <div class="cb-a-large cb-box cb-module-block clearfix">
        <?php if ($cb_title != NULL) { echo  '<div class="cb-module-title" >' . $cb_title . '</div>'; } ?>
   		<?php echo do_shortcode( $cb_ad_code ) ; ?>
	</div>