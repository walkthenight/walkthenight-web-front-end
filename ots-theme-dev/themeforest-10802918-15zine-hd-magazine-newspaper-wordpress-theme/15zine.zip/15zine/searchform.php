<form role="search" method="get" class="cb-search" action="<?php echo home_url( '/' ); ?>">

    <input type="text" class="cb-search-field cb-font-header" placeholder="<?php _e('Search..', 'cubell'); ?>" value="" name="s" title="" autocomplete="off">
    <button class="cb-search-submit" type="submit" value=""><i class="fa fa-search"></i></button>
    
</form>